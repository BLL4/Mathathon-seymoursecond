# Slides for a research talk on *Seymour's second-neighborhood conjecture*

A Beamer deck for the paper draft in `../rewrite-claude-opus-5.5/paper/`
(itself a rewrite of the OpenAI preprint *A proof of Seymour's second-neighborhood
conjecture*, 23 September 2026).  The deck is built slide by slide.

* Deck: [`main.pdf`](main.pdf) (also `build/main.pdf`)
* Source: `main.tex` (preamble + `\input` per slide), `s01-problem.tex`, `figures/`
* Build: `latexmk -pdf -interaction=nonstopmode -outdir=build main.tex`
  (`bash checks/build.sh` prints frame count, overfull boxes, warnings;
  captured in `checks/outputs.txt`)
* Render check: `pdftoppm -png -r 150 build/main.pdf build/slide` and look at
  `build/slide-*.png` — do not trust the log alone, a block can end up pressed
  against the footline with no overfull reported.

## Conventions

* House style of the OpenMath exposition deck: Boadilla, `mainblue`
  (26,64,133), `accent` (176,86,20), `softblue` (232,239,250); 16:9, 11pt.
* Same colours as the paper for the two neighbourhoods: `famL` blue =
  $N^+_1(v)$, `famR` orange = $N^+_2(v)$.
* Notation follows the draft: `\Nout` $=N^+_1$, `\Ntwo` $=N^+_2$,
  `\Nbar` $=\overline N$; all statements cite the draft's numbering
  (e.g. "Corollary 6.2").
* Authors and PDF metadata are set in `main.tex` (`\author`, `\hypersetup`);
  the title page itself is `s00-title.tex`, so edit names there.

## Slides

0. `s00-title.tex` — title page: title, the OpenAI preprint as the source, and
   the three authors with affiliations (An Cao, Caltech; Bernard Lidický, Iowa
   State; Jan Volec, CTU Prague).  The title page is numbered like any frame.
1. `s01-problem.tex` — the problem and the news: statement of Seymour's
   conjecture with a figure, the OpenAI theorem, and Corollary 6.2
   (directed triangles) with its consequence, the $g=4$ case of
   Behzad–Chartrand–Wall (1970).
2. `s02-reduction.tex` — Section 2 in three stages: the minimal
   counterexample, the subset deficit (Lemma 2.2, inequality (1), after
   Seacrest 2019, Lemma 4), and the blow-up by transitive tournaments
   (Lemma 2.6, inequality (6)), ending with (G1) + (G2).
3. `s03-pairs.tex` — Section 3 in three blocks: conflict and compatibility
   with the conflict rectangle (Def. 3.2, Def. 3.4, the grid figure),
   `unc`/`val`/admissible pairs and Lemma 3.6, then the §3.4 plan: a
   maximum admissible pair cannot exist.  The figure is
   `figures/grid-conflict.tex`, adapted from the draft's Figure 5 (grid and
   conflict rectangle, no caption, no relation panel).
4. `s04-pruning.tex` — Section 4: the gain from (P,Q) to (R,C), the need to
   repair it, Lemma 4.1 (pruning) with (P1)–(P3), its proof via the matching
   bound and König + rank–nullity/Sylvester, and the short finish
   `val(R',C') > val(P,Q)`.
5. `s05-proof.tex` — proof summary: the six steps in two columns (a
   counterexample forces $G$: minimal counterexample, subset deficit, blow-up;
   such a $G$ is impossible: choose, concavity, prune), rebuilt from
   `../proof-overview.tex` in the deck's palette and notation.  The original
   file used the `slides-report` colours (`navy`, `rust`), `\tiny` box text,
   `u`/`u'` for the uncovered counts and "Lemma 2.3" for the blow-up; the
   slide uses `mainblue`/`accent`, `\footnotesize`, `d`/`d'` and Lemma 2.6.
6. `s06-whatnext.tex` — closing slide: what we understand and what we do not
   (grid picture, pruning lemma), the three Lean proofs to human-verify, and
   Sullivan's Conjecture 6.6 (Compromise) and Burckel's Conjecture 6.13,
   both from arXiv:math/0605646 §6.

## What is deliberately not on slide 1

The third consequence of Corollary 6.2 -- "$\delta^{+},\delta^{-}\ge n/3$
forces a directed triangle", i.e. the $n/3$ case of Caccetta--Häggkvist --
was on the slide in a longer version and was dropped to keep the corollary
band at three lines with air above the footline.  It belongs on a
consequences slide later in the talk.

## Sources checked for slide 4

* `paper/sec4-pruning.tex`: Lemma 4.1, and its own description of the proof
  ("a purely combinatorial reduction ... a linear-algebra proof of this
  matching bound").  The matching bound nu(Gamma) <= |Z| + |H| is
  Proposition 4.8 in the draft, not a numbered lemma; it is proved with
  rank-nullity and Sylvester's inequality from NL = AB.
* `paper/sec5-contradiction.tex`: Claim 5.4 (gain), Claim 5.6 (|H| <= d),
  Claim 5.7 (at most d' conflict points stay uncovered) and the Conclusion,
  which is the displayed chain on the slide.  Deletions are at most
  |H| + d' <= d + d' and the d' uncovered points return in val, so the net
  price of the repair is at most d.

## Numbering note (slide 3)

The draft numbers Section 3 as 3.1 coordinate images, 3.2 conflict and
compatibility (Def. 3.2, Lem. 3.3, Def. 3.4), 3.3 the extremal set-up
(Def. 3.5, Lem. 3.6), 3.4 the plan (Remark 3.7).  Items requested as
"Definition 3.3", "Definition 3.7", "Definition 3.9" and "Lemma 3.10" do not
exist under those numbers in the draft's PDF; the slide uses the draft's
numbers for the corresponding content (conflict / Z, H = Def. 3.2 and 3.4;
value and admissible = Def. 3.5; the extremal pair and the ledger = §3.4).
Figure 6 of the draft is the ledger bar chart; the grid picture is Figure 5.

## Sources checked for slide 2

* `paper/sec2-reduction.tex`; in the compiled draft: Lemma 2.2 with
  inequality (1) on p. 6, Lemma 2.6 with inequality (6) on p. 8, the
  proof map of Figure 2, and Remark 2.3 (the error term behind the
  blow-up).  Lemma 2.6 is the draft's numbering; the original preprint
  numbers it 2.3.
* The right-hand side of Seacrest's Lemma 4 is $|F(S)|$; inequality (1)
  has the stronger $|F(S)\setminus S|$, which is what minimality in the
  number of vertices (hence strong connectivity) buys.  Box 2 says so in
  one clause.

## Sources checked for slide 1

* Seymour's conjecture and Dean–Latka (1995): `paper/sec1-intro.tex`.
* Corollary 6.2 (three parts) and its proof: `paper/sec6-consequences.tex`;
  in the compiled draft it is Corollary 6.2 on p. 25.
* Behzad–Chartrand–Wall (1970), *On minimal regular digraphs with given
  girth*: the conjecture is Conjecture 4.1 of Sullivan's survey
  (arXiv:math/0605646): "the minimum number of vertices in an $r$-regular
  digraph with girth $g$ is $r(g-1)+1$".  Note the survey's extremal example
  (a circulant with steps $1,\dots,r$) has digons, so Seymour's conjecture
  gives the oriented case only; the slide says "oriented $g=4$ case".
