#!/bin/bash
# Build the deck and report the numbers that matter: frame count, overfull
# boxes, undefined references, LaTeX warnings.  Run from the deck directory:
#   bash checks/build.sh
set -u
cd "$(dirname "$0")/.." || exit 1
latexmk -pdf -interaction=nonstopmode -outdir=build main.tex >/dev/null 2>&1
status=$?
log=build/main.log
if [ ! -f "$log" ]; then echo "no log produced"; exit 1; fi
pages=$(pdfinfo build/main.pdf 2>/dev/null | awk '/^Pages:/{print $2}')
frames=$(grep -c '\\begin{frame}' main.tex s[0-9]*.tex 2>/dev/null | awk -F: '{s+=$2} END{print s}')
echo "latexmk exit        : $status"
echo "pdf pages           : ${pages:-?}"
echo "frame environments  : ${frames:-?}"
echo "overfull hbox/vbox  : $(grep -c 'Overfull' "$log" || true)"
echo "underfull hbox/vbox : $(grep -c 'Underfull' "$log" || true)"
echo "undefined refs/cites: $(grep -c 'undefined' "$log" || true)"
echo "LaTeX warnings      : $(grep -c 'LaTeX Warning' "$log" || true)"
echo "missing characters  : $(grep -c 'Missing character' "$log" || true)"
grep -E 'Overfull|Underfull|LaTeX Warning|Missing character' "$log" | head -20
